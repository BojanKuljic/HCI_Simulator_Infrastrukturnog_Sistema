﻿using NetworkService.Model;
using NetworkService.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace NetworkService.ViewModel
{
    public class NetworkDisplayViewModel : BindableBase
    {
        public static ObservableCollection<Reaktor> ServeriView2 { get { return serveriView2; } set { if (serveriView2 != value) serveriView2 = value; } }
        static ObservableCollection<Reaktor> serveriView2 = new ObservableCollection<Reaktor>();
        private string draggedItem = "";
        private bool dragging = false;
        private bool IzmedjuDvaCanvasa = false;
        private int Id;
        private string Name;
        private Reaktor selectedItemListView;
        public MyICommand MouseLeftButtonUpCommand { get; set; }
        public MyICommand SelectionChangedCommand { get; set; }
        public MyICommand<Canvas> DropCommand { get; set; }
        public MyICommand<Canvas> FreeCommand { get; set; }
        public MyICommand LoadCommand { get; set; }
        public MyICommand<Canvas> OnLoadCanvas { get; set; }
        public MyICommand<Canvas> MouseLeftButtonUpCanvasCommand { get; set; }
        public MyICommand<Canvas> MouseLeftButtonDownCanvasCommand { get; set; }
        public static Dictionary<Canvas, int> ListaZauzetihKanvasa = new Dictionary<Canvas, int>();


        public NetworkDisplayViewModel()
        {           
            MouseLeftButtonUpCommand = new MyICommand(OnMouseLeftButtonUp);
            SelectionChangedCommand = new MyICommand(OnSelectionChanged);
            DropCommand = new MyICommand<Canvas>(OnDrop);
            FreeCommand = new MyICommand<Canvas>(OnFree);
            LoadCommand = new MyICommand(OnLoad);
            MouseLeftButtonUpCanvasCommand = new MyICommand<Canvas>(OnMouseLeftButtonUpCanvas);
            MouseLeftButtonDownCanvasCommand = new MyICommand<Canvas>(OnMouseLeftButtonDownCanvas);
            OnLoadCanvas = new MyICommand<Canvas>(CanvasLoad);
            UpdateValues();
        }

        private void OnLoad()
        {
            foreach (Reaktor s in ServerViewModel.Reaktori)
            {
                if (!ServeriView2.Contains(s) && !ListaZauzetihKanvasa.Values.Contains(s.Id) && s != null)
                    ServeriView2.Add(s);
            }
        }

        private void CanvasLoad(Canvas c)
        {/*
            foreach (Canvas canvas in ListaZauzetihKanvasa.Keys)
            {
                if (canvas.Name == c.Name)
                {            
                    foreach (Server s in ServerViewModel.Serveri)
                        if (s.Id == ListaZauzetihKanvasa[canvas])
                        {
                            BitmapImage bitmapImage = new BitmapImage();
                            bitmapImage.BeginInit();
                            bitmapImage.UriSource = new Uri(s.Img_src);
                            bitmapImage.EndInit();
                            c.Background = new ImageBrush(bitmapImage);
                            ((TextBlock)c.Children[1]).Text = s.Id + "," + s.Name;
                            c.Resources.Add("taken", true);
                            break;
                        }                  
                }
            }*/
        }


        public Reaktor SelectedItemListView
        {
            get { return selectedItemListView; }
            set { selectedItemListView = value; OnPropertyChanged("SelectedItemListView"); }
        }

        private async Task UpdateValues()
        {
            while (true)
            {
                foreach (Canvas c in ListaZauzetihKanvasa.Keys)
                {               
                    int id = int.Parse(((TextBlock)c.Children[1]).Text.Split(',')[0]);

                    foreach (Reaktor server in ServerViewModel.Reaktori)
                        if (server.Id == id)
                        {
                            BitmapImage bitmapImage = new BitmapImage();
                            bitmapImage.BeginInit();
                            bitmapImage.UriSource = new Uri(server.Img_src);
                            bitmapImage.EndInit();
                            c.Background = new ImageBrush(bitmapImage);
                            break;
                        }                   
                   
                }
                await Task.Delay(1000);
            }
        }

        private void OnMouseLeftButtonUpCanvas(Canvas sender)
        {
            draggedItem = "";
            dragging = false;
            IzmedjuDvaCanvasa = false;
        }

        private void OnMouseLeftButtonDownCanvas(Canvas sender)
        {
            if (!dragging && ListaZauzetihKanvasa.ContainsKey(sender) && !IzmedjuDvaCanvasa)
            {
                dragging = true;
                IzmedjuDvaCanvasa = true;
                string[] niz = ((TextBlock)sender.Children[1]).Text.Split(',');
                int idd = Int32.Parse(niz[0]);
                foreach (Reaktor s in ServerViewModel.Reaktori)
                {
                    if (s.Id == idd)
                        draggedItem = s.Img_src;
                }
                this.Id = idd;
                this.Name = niz[1];
                DragDrop.DoDragDrop(new NetworkDisplayView(), draggedItem, DragDropEffects.Move);
            }
        }

        private void OnMouseLeftButtonUp()
        {
            draggedItem = "";
            SelectedItemListView = null;
            dragging = false;
        }

        private void OnSelectionChanged()
        {
            if (!dragging)
            {
                dragging = true;
                draggedItem = SelectedItemListView.Img_src;
                IzmedjuDvaCanvasa = false;
                this.Id = SelectedItemListView.Id;
                this.Name = SelectedItemListView.Name;
                DragDrop.DoDragDrop(new NetworkDisplayView(), draggedItem, DragDropEffects.Move);
            }
        }

        private void OnDrop(Canvas sender)
        {
            if (draggedItem != "" && !IzmedjuDvaCanvasa)
            {
                if (sender.Resources["taken"] == null)
                {
                    BitmapImage pozadina = new BitmapImage();
                    pozadina.BeginInit();
                    pozadina.UriSource = new Uri(draggedItem, UriKind.Relative);
                    pozadina.EndInit();
                    sender.Background = new ImageBrush(pozadina);
                    ((TextBlock)sender.Children[1]).Text = this.Id + "," + this.Name;
                    sender.Resources.Add("taken", true);
                    ServeriView2.Remove(selectedItemListView);

                    ListaZauzetihKanvasa.Add(sender, Id);
                }
            }

            else if (draggedItem != "" && IzmedjuDvaCanvasa)
            {
                if (sender.Resources["taken"] == null)
                {
                    foreach (Canvas c in ListaZauzetihKanvasa.Keys)
                    {
                        string[] niz = ((TextBlock)c.Children[1]).Text.Split(',');
                        int idd_test = Int32.Parse(niz[0]);
                        if (idd_test == this.Id)
                        {
                            c.Background = Brushes.White;
                            ((TextBlock)c.Children[1]).Text = "ID,Name";

                            c.Resources.Remove("taken");
                            ListaZauzetihKanvasa.Remove(c);
                            break;

                        }
                    }
                    BitmapImage bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(draggedItem, UriKind.Relative);
                    bitmap.EndInit();
                    sender.Background = new ImageBrush(bitmap);
                    ((TextBlock)sender.Children[1]).Text = this.Id + "," + this.Name;
                    sender.Resources.Add("taken", true);

                    ListaZauzetihKanvasa.Add(sender, Id);

                }
            }
            SelectedItemListView = null;
            dragging = false;
            IzmedjuDvaCanvasa = false;
            draggedItem = "";
        }



        private void OnFree(Canvas sender)
        {
            if (sender.Resources["taken"] != null)
            {
                sender.Background = Brushes.White;

                string[] niz = ((TextBlock)sender.Children[1]).Text.Split(',');
                int idd = Int32.Parse(niz[0]);

                ((TextBlock)sender.Children[1]).Text = "ID,Name";

                foreach (Reaktor s in ServerViewModel.Reaktori)
                {
                    if (s.Id == idd)
                    {
                        ServeriView2.Add(s);
                        ListaZauzetihKanvasa.Remove(sender);
                        break;
                    }
                }
                sender.Resources.Remove("taken");
            }
        }
    }
}
