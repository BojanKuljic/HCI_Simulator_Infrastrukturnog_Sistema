﻿using Microsoft.Win32;
using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace NetworkService.ViewModel
{
    public class ServerViewModel : BindableBase
    {
        private static int index = 0;
        private static int indexFilter = 0;
        private string slika = "/slike/RTD.jpg";
        //private string slika = "";

        public static ObservableCollection<Reaktor> Reaktori = new ObservableCollection<Reaktor>();
        public  ObservableCollection<Reaktor> ServeriView1 { get { return serverView1; } set { if (serverView1 != value) { serverView1 = value; OnPropertyChanged("ServeriView1"); } } }
        ObservableCollection<Reaktor> serverView1;
        public MyICommand DeleteCommand { get; set; }
        public MyICommand AddCommand { get; set; }
        public MyICommand<TextBox> GotFocusCommand { get; set; }
        public MyICommand LoadCommand { get; set; }
        private Reaktor currentReactor = new Reaktor() { Img_src = "/slike/RTD.png" };
        private Reaktor selectedReactor;
        private string selecteddID; //ovo promenio i currentReactor
        private bool radiobutton_manje_checked;
        private bool radiobutton_vece_checked;
        private bool radiobutton_jednako_checked;
        private string id_filter_tb;
        public static BindingList<string> IDD { get; set; }
        public MyICommand FilterCommand { get; set; }
        public MyICommand ResetFilterCommand { get; set; }

        public ServerViewModel()
        {
            ServeriView1 = new ObservableCollection<Reaktor>();
            DeleteCommand = new MyICommand(OnDelete, CanDelete);
            AddCommand = new MyICommand(OnAdd);
            GotFocusCommand = new MyICommand<TextBox>(OnGotFocus);
            FilterCommand = new MyICommand(OnFilter);
            ResetFilterCommand = new MyICommand(OnResetFilter);
            LoadCommand = new MyICommand(OnLoad);
            IDD = MainWindowViewModel.IdSacuvano;
            string fullPath = "Log.txt";
            if (File.Exists(fullPath))
            {
                File.Delete(fullPath);
            }
          //  File.Delete(fullPath);
            index = 0;
            Id_filter_tb = string.Empty;
           
        }

       

        public string Slika
        {
            get
            {
                return slika;
            }

            set
            {
                if (slika != value)
                {
                    slika = value;
                    OnPropertyChanged("Slika");
                }
            }
        }
        public int Index
        {
            get
            {
                return index;
            }
            set
            {
                if (index != value)
                {
                    if (index != 0)
                    {
                        Slika = "/slike/RTD.png";
                        
                    }
                    else
                    {
                        Slika = "/slike/Thermocouple.png";
                       
                        OnPropertyChanged("Index");
                    }
                    index = value;
                }
            }

        }

        public int IndexFilter
        {
            get
            {
                return indexFilter;
            }
            set
            {
                if (indexFilter != value)
                {
                    indexFilter = value;
                    OnPropertyChanged("IndexFilter");
                }
            }

        }
        public Reaktor SelectedReactor                                         
        {
            get { return selectedReactor; }
            set
            {
                selectedReactor = value;
                DeleteCommand.RaiseCanExecuteChanged();       
            }
        }

    private void OnLoad()
        {
            ServeriView1 = new ObservableCollection<Reaktor>();
            foreach (Reaktor s in Reaktori)
                ServeriView1.Add(s);
        }

    

    public bool Radiobutton_manje_checked
        {
            get { return radiobutton_manje_checked; }
            set
            {
                radiobutton_manje_checked = value;
                
                OnPropertyChanged("Radiobutton_manje_checked");
            }
        }

      public bool Radiobutton_vece_checked
        {
            get { return radiobutton_vece_checked; }
            set
            {
                radiobutton_vece_checked = value;
                OnPropertyChanged("Radiobutton_vece_checked");
            }
        }
        public bool Radiobutton_jednako_checked
        {
            get { return radiobutton_jednako_checked; }
            set
            {
                radiobutton_jednako_checked = value;
                OnPropertyChanged("Radiobutton_jednako_checked");
            }
        }

        public string Id_filter_tb
        {
            get { return id_filter_tb; }
            set
            {
                id_filter_tb = value;
                OnPropertyChanged("Id_filter_tb");
            }
        }

        public Reaktor CurrentReactor
        {
            get { return currentReactor; }
            set
            {
                if(currentReactor != value)
                {
                    currentReactor = value;
                    OnPropertyChanged("CurrentReactor");
                }
            }
        }

        public void OnGotFocus(TextBox tb)
        {
            MainWindowViewModel.FocusedTextBox = tb;           
        }

        private void OnFilter()
        {
            ServeriView1 = new ObservableCollection<Reaktor>();
           
            if ((radiobutton_manje_checked || radiobutton_vece_checked || radiobutton_jednako_checked))
            {
                
                try {

                    
                    string odabrano = "";
                    if (IndexFilter == 0)
                    {
                        odabrano = "RTD";
                    }
                    else
                    {
                        odabrano = "Thermocouple";
                    }

                    int id = Int32.Parse((Id_filter_tb));
                   
                    if (Radiobutton_vece_checked)
                    {
                       
                        foreach (Reaktor s in Reaktori)
                        {
                            if (s.Id > id && s.TipR.Naziv.Equals(odabrano)) 
                            {
                                serverView1.Add(s);
                            }
                        }                           
                     }
                    
                    else if (Radiobutton_manje_checked)
                     {
                        foreach (Reaktor s in Reaktori)
                        {
                            if (s.Id < id && s.TipR.Naziv.Equals(odabrano))
                            {
                                serverView1.Add(s);
                            }
                        }
                     }
                    else if(Radiobutton_jednako_checked)
                    {
                        foreach (Reaktor s in Reaktori)
                        {
                            if (s.Id == id && s.TipR.Naziv.Equals(odabrano))
                            {
                                serverView1.Add(s);
                            }
                        }

                    }
                   

                }
                 catch(Exception e)
                {
                    Id_filter_tb = "Unesite broj.";
                }
            }
            else if(!Radiobutton_manje_checked && !Radiobutton_vece_checked && !Radiobutton_jednako_checked )
            {
               
                string odabrano = "";
                if (IndexFilter == 0)
                {
                    odabrano = "RTD";
                }
                else
                {
                    odabrano = "Thermocouple";
                }
                foreach (var item in Reaktori)
                {
                    if(item.TipR.Naziv.Equals("RTD") && odabrano =="RTD")
                    {
                        serverView1.Add(item);
                    }
                    else if (item.TipR.Naziv.Equals("Thermocouple") &&  odabrano == "Thermocouple")
                    {
                        serverView1.Add(item);
                    }

                }
            }
            else
            {
                try
                {
                    int id = Int32.Parse(Id_filter_tb);                    
                    if (Radiobutton_vece_checked)
                    {

                        foreach (Reaktor s in Reaktori)
                        {
                            if (s.Id > id )
                            {
                                serverView1.Add(s);
                            }
                        }
                    }
                    else if (Radiobutton_manje_checked)
                    {
                        foreach (Reaktor s in Reaktori)
                        {
                            if (s.Id < id )
                            {
                                serverView1.Add(s);
                            }
                        }
                    }
                    else if (Radiobutton_jednako_checked)
                    {
                        foreach (Reaktor s in Reaktori)
                        {
                            if (s.Id == id)
                            {
                                serverView1.Add(s);
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    Id_filter_tb = "Unesite Broj.";
                }
            }                 
        }

        private void OnResetFilter()
        {
            ServeriView1 = new ObservableCollection<Reaktor>();
            foreach (Reaktor s in Reaktori)
                ServeriView1.Add(s);
        }

        public void OnAdd()
        {      
            CurrentReactor.Validate();
            if (CurrentReactor.IsValid)
            {
                Tip tipnovi;
                if (Index == 0)
                {
                    tipnovi = new Tip() { Naziv = "RTD", Slika = CurrentReactor.Img_src };
                }
                else
                {
                    tipnovi = new Tip() { Naziv = "Thermocouple", Slika = CurrentReactor.Img_src };
                }
                Reaktori.Add(new Reaktor() { Id = CurrentReactor.Id, Name = CurrentReactor.Name, TipR = tipnovi, Img_src = Slika});
                ServeriView1.Add(new Reaktor() { Id = CurrentReactor.Id, Name = CurrentReactor.Name, TipR = tipnovi, Img_src = Slika});
                OnResetFilter();
                if (!MainWindowViewModel.IdSacuvano.Contains(CurrentReactor.Id.ToString()))
                {
                    MainWindowViewModel.IdSacuvano.Add(CurrentReactor.Id.ToString());
                    IDD = MainWindowViewModel.IdSacuvano;
                    MainWindowViewModel.EntitetiSacuvano.Add(CurrentReactor.Name);
                    MainWindowViewModel.Entities.Add(CurrentReactor);
                }

                MainWindowViewModel.undoKomanda = "Add";
                MainWindowViewModel.undoReactor = CurrentReactor;

                CurrentReactor.Id_TextBox = "";            
                Index=0;
                CurrentReactor.Name = "";        
            }         
        }

        private bool CanDelete()
        {
            return SelectedReactor != null;   
        }

        private void OnDelete()
        {
            
            IDD = MainWindowViewModel.IdSacuvano;
            MainWindowViewModel.EntitetiSacuvano.Remove(SelectedReactor.Name);
            NetworkDisplayViewModel.ServeriView2.Remove(SelectedReactor);
            MainWindowViewModel.undoReactor = SelectedReactor;
            MainWindowViewModel.undoKomanda = "Delete";
            Reaktori.Remove(SelectedReactor);
            ServeriView1.Remove(SelectedReactor);

           
                                       
        }
      

    }
}
