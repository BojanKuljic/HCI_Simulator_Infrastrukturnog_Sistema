﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NetworkService.ViewModel
{
    public class MainWindowViewModel : BindableBase
    {

        private int count;
        private int flag;         
        public static BindingList<string> IdSacuvano { get; set; }
        public static BindingList<string> EntitetiSacuvano { get; set; }
        public static ObservableCollection<Reaktor> Entities = new ObservableCollection<Reaktor>();

        public MyICommand<String> NavCommand { get; private set; }
        private ServerViewModel serverViewModel = new ServerViewModel();
        private NetworkDisplayViewModel networkDisplayViewModel = new NetworkDisplayViewModel();
        private GraphViewModel measurementGraphViewModel = new GraphViewModel();
        private BindableBase currentViewModel;
        public MyICommand<String> KeyCommand { get; private set; }
        public MyICommand HomeCommand { get; set; }
        public MyICommand UndoCommand { get; set; }
        public static Reaktor undoReactor { get; set; }
        public static string undoKomanda { get; set; }

        public static TextBox FocusedTextBox { get; set; }
        public BindableBase CurrentViewModel
        {
            get { return currentViewModel; }
            set
            {
                SetProperty(ref currentViewModel, value);   //kom polju postavljamo i sta postavljamo
            }
        }

        public MainWindowViewModel()
        {
            createListener(); //Povezivanje sa serverskom aplikacijom
            ServerViewModel.Reaktori = new ObservableCollection<Reaktor>();
            NavCommand = new MyICommand<string>(OnNav);
            KeyCommand = new MyICommand<string>(OnKeyPress);
            CurrentViewModel = serverViewModel;
            IdSacuvano = new BindingList<string>();
            EntitetiSacuvano = new BindingList<string>();
           // Entities = new ObservableCollection<Reaktor>();
            HomeCommand = new MyICommand(OnHome);
            UndoCommand = new MyICommand(OnUndo);
        }

        private void OnNav(string destination)
        {
            switch (destination)
            {
                case "entities":
                    CurrentViewModel = serverViewModel;
                    break;
                case "display":
                    CurrentViewModel = networkDisplayViewModel;
                    break;
                case "graph":
                    CurrentViewModel = measurementGraphViewModel;
                    break;
            }
        }

        private void OnHome()
        {
            CurrentViewModel = serverViewModel;
        }

        private void OnUndo()
        {
            if(undoKomanda == "Add")
            {
               //ServerViewModel.Reaktori.Remove(undoReactor);
               // serverViewModel.ServeriView1.Remove(undoReactor);
            }
            else if(undoKomanda == "Delete")
            {
                //ServerViewModel.Reaktori.Add(undoReactor);
                //serverViewModel.ServeriView1.Add(undoReactor);
            }
                
        }

       private void OnKeyPress(string Key)
        {
            if(FocusedTextBox != null)
            {
                if (Key.Equals("delete"))
                {
                    if (FocusedTextBox.Text.Trim().Length > 0)
                    {
                        FocusedTextBox.Text = FocusedTextBox.Text.Substring(0, FocusedTextBox.Text.Trim().Length - 1);                      
                    }
                }
                else if (Key.Equals("shift"))
                {
                    flag = 1;
                }
                else if (Key.Equals("space"))
                {
                    FocusedTextBox.Text = FocusedTextBox.Text + " ";                   
                }
                else
                {
                    if (flag == 1)
                    {
                        FocusedTextBox.Text = FocusedTextBox.Text + Char.ToUpper(Char.Parse(Key));                     
                        flag = 0;
                    }
                    else
                    {
                        FocusedTextBox.Text = FocusedTextBox.Text + Key;                     
                    }
                }
            }
            
            
        }

    private void createListener()
        {
            var tcp = new TcpListener(IPAddress.Any, 25565);
            tcp.Start();

            var listeningThread = new Thread(() =>
            {
                while (true)
                {
                    var tcpClient = tcp.AcceptTcpClient();
                    ThreadPool.QueueUserWorkItem(param =>
                    {
                        //Prijem poruke
                        NetworkStream stream = tcpClient.GetStream();
                        string incomming;
                        int pozicija;
                        double nova_vrednost;
                        byte[] bytes = new byte[1024];
                        int i = stream.Read(bytes, 0, bytes.Length);
                        //Primljena poruka je sacuvana u incomming stringu
                        incomming = System.Text.Encoding.ASCII.GetString(bytes, 0, i);

                        //Ukoliko je primljena poruka pitanje koliko objekata ima u sistemu -> odgovor
                        if (incomming.Equals("Need object count"))
                        {
                            //Response
                            /* Umesto sto se ovde salje count.ToString(), potrebno je poslati 
                             * duzinu liste koja sadrzi sve objekte pod monitoringom, odnosno
                             * njihov ukupan broj (NE BROJATI OD NULE, VEC POSLATI UKUPAN BROJ)
                             * */
                            count = ServerViewModel.Reaktori.Count();
                            Byte[] data = System.Text.Encoding.ASCII.GetBytes(count.ToString());
                            
;                           stream.Write(data, 0, data.Length);
                        }
                        else
                        {
                            //U suprotnom, server je poslao promenu stanja nekog objekta u sistemu
                            Console.WriteLine(incomming); //Na primer: "Entitet_1:272"

                            //################ IMPLEMENTACIJA ####################
                            // Obraditi poruku kako bi se dobile informacije o izmeni
                            // Azuriranje potrebnih stvari u aplikaciji

                            string sacuvano = incomming;

                            incomming = incomming.Remove(0, 8);

                            string[] words = incomming.Split(':');

                            nova_vrednost = Double.Parse(words[1]);
                            pozicija = Int32.Parse(words[0]);

                        if (ServerViewModel.Reaktori != null && ServerViewModel.Reaktori.Count() != 0 )
                            {
                                //Ovdje je bacilo neki bag
                                //SVAKI PUT KADA DODAMO NOVU VREDNOST TREBA DA RESTRATUJEMO SILMULATOR

                                ServerViewModel.Reaktori[pozicija].Value = nova_vrednost;

                                
                                string fullPath = "Log.txt";
                                using (StreamWriter writer = File.AppendText(fullPath))
                                {
                                    writer.WriteLine(DateTime.Now.ToString() + " " + sacuvano);
                                }


                                //ovo promeniti da kada se izabere 1 iz liste da se ta slika prikaze
                                if(nova_vrednost < 250 || nova_vrednost > 350)
                                {
                                    if(ServerViewModel.Reaktori[pozicija].TipR.Naziv.Equals("RTD"))
                                        ServerViewModel.Reaktori[pozicija].Img_src = "/slike/RTD-NotOk.png";
                                    else
                                        ServerViewModel.Reaktori[pozicija].Img_src = "/slike/Thermocouple-NotOK.png";
                                }
                                else
                                {
                                    if (ServerViewModel.Reaktori[pozicija].TipR.Naziv.Equals("RTD"))
                                        ServerViewModel.Reaktori[pozicija].Img_src = "/slike/RTD-OK.png";
                                    else
                                        ServerViewModel.Reaktori[pozicija].Img_src = "/slike/Thermocouple-OK.png";
                                }
                            }
                        }
                    }, null);
                }
            });

            listeningThread.IsBackground = true;
            listeningThread.Start();
        }

        
}
}
