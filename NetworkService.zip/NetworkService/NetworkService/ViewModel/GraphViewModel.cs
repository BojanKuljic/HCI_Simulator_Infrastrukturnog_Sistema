﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NetworkService.ViewModel
{
    public class GraphViewModel : BindableBase
    {
        public static BindingList<string> lista { get; set; }
        public MyICommand buttonCommand { get; set; }
        public string SelectedItem { get; set; }
        public List<string> linije = new List<string>();
        private bool clicked;
       
        string vreme1;
        string vreme2;
        string vreme3;
        string vreme4;
        string vreme5;
        public string Vreme1 { get { return vreme1; } set { vreme1 = value; OnPropertyChanged("Vreme1"); } }
        public string Vreme2 { get { return vreme2; } set { vreme2 = value; OnPropertyChanged("Vreme2"); } }
        public string Vreme3 { get { return vreme3; } set { vreme3 = value; OnPropertyChanged("Vreme3"); } }
        public string Vreme4 { get { return vreme4; } set { vreme4 = value; OnPropertyChanged("Vreme4"); } }
        public string Vreme5 { get { return vreme5; } set { vreme5 = value; OnPropertyChanged("Vreme5"); } }
       

        int radius1;
        int radius2;
        int radius3;
        int radius4;
        int radius5;
        public int Radius1 { get { return radius1; } set { radius1 = value; OnPropertyChanged("Radius1"); } }
        public int Radius2 { get { return radius2; } set { radius2 = value; OnPropertyChanged("Radius2"); } }
        public int Radius3 { get { return radius3; } set { radius3 = value; OnPropertyChanged("Radius3"); } }
        public int Radius4 { get { return radius4; } set { radius4 = value; OnPropertyChanged("Radius4"); } }        
        public int Radius5 { get { return radius5; } set { radius5 = value; OnPropertyChanged("Radius5"); } }        
        
        Brush brush1;
        Brush brush2;
        Brush brush3;
        Brush brush4;
        Brush brush5;

       
        public Brush Brush1 { get { return brush1; } set { brush1 = value; OnPropertyChanged("Brush1"); } }
        public Brush Brush2 { get { return brush2; } set { brush2 = value; OnPropertyChanged("Brush2"); } }
        public Brush Brush3 { get { return brush3; } set { brush3 = value; OnPropertyChanged("Brush3"); } }
        public Brush Brush4 { get { return brush4; } set { brush4 = value; OnPropertyChanged("Brush4"); } }
        public Brush Brush5 { get { return brush5; } set { brush5 = value; OnPropertyChanged("Brush5"); } }
       
        public string Provera { get { return provera; } set { provera = value; OnPropertyChanged("Provera"); } }
        private string provera = "";
        public GraphViewModel()
        {
            lista = MainWindowViewModel.EntitetiSacuvano;
           
            buttonCommand = new MyICommand(ButtonClicked);
            UpdateValues();
        }

        private async Task UpdateValues()
        {
            while (true)
            {
                if (clicked)
                    ButtonClicked();
                await Task.Delay(1000);
            }
        }

        public void ButtonClicked()
        {
            Provera = "";
            clicked = true;
            int c = 0;
            List<int> vrednosti = new List<int>();
            List<DateTime> datumi = new List<DateTime>();
            using (var fileStream = File.OpenRead("Log.txt"))
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, 128))
            {
                String line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    linije.Add(line);
                }
            }

            for (int i = linije.Count - 1; i >= 0; i--)
            {
                string[] l = linije[i].Split(' ');

                l = l[2].Split(':');

                string[] test = l[0].Split('_');
                int idx = Int32.Parse(test[1]);
                if (idx < ServerViewModel.Reaktori.Count)
                    if (ServerViewModel.Reaktori[idx].Name == SelectedItem)
                    {
                        if (c < 5)
                        {
                            string[] l2 = linije[i].Split(' ');
                            string[] l1 = l2[0].Split('.');
                            int d = int.Parse(l1[0]);
                            int m = int.Parse(l1[1]);
                            int g = int.Parse(l1[2]);
                            l1 = l2[1].Split(':');
                            int s = int.Parse(l1[0]);
                            int min = int.Parse(l1[1]);
                            int sek = int.Parse(l1[2]);
                            DateTime dt = new DateTime(g, m, d, s, min, sek);                           
                            datumi.Add(dt);
                            vrednosti.Add(int.Parse(l[1]));
                            c++;
                        }
                        else break;
                    }
            }
            try
            {
                Radius1 = Convert.ToInt32((Convert.ToDouble(vrednosti[0]) / 100) * 16);
                Radius2 = Convert.ToInt32((Convert.ToDouble(vrednosti[1]) / 100) * 16);
                Radius3 = Convert.ToInt32((Convert.ToDouble(vrednosti[2]) / 100) * 16);
                Radius4 = Convert.ToInt32((Convert.ToDouble(vrednosti[3]) / 100) * 16);
                Radius5 = Convert.ToInt32((Convert.ToDouble(vrednosti[4]) / 100) * 16);
                
                if (vrednosti[0] > 350 || vrednosti[0] < 250)
                    Brush1 = Brushes.Red;
                else
                    Brush1 = Brushes.Green;

                if (vrednosti[1] > 350 || vrednosti[1] < 250)
                    Brush2 = Brushes.Red;
                else
                    Brush2 = Brushes.Green;

                if (vrednosti[2] > 350 || vrednosti[2] < 250)
                    Brush3 = Brushes.Red;
                else
                    Brush3 = Brushes.Green;

                if (vrednosti[3] > 350 || vrednosti[3] < 250)
                    Brush4 = Brushes.Red;
                else
                    Brush4 = Brushes.Green;

                if (vrednosti[4] > 350 || vrednosti[4] < 250)
                    Brush5 = Brushes.Red;
                else
                    Brush5 = Brushes.Green;



                if (Radius1 > 100)
                    Radius1 = 95;
                else if (Radius1 < 30)
                    Radius1 = 30;

                if (Radius2 > 100)
                    Radius2 = 95;
                else if (Radius2 < 30)
                    Radius2 = 30;

                if (Radius3 > 100)
                    Radius3 = 95;
                else if (Radius3 < 30)
                    Radius3 = 30;

                if (Radius4 > 100)
                    Radius4 = 95;
                else if (Radius4 < 30)
                    Radius4 = 30;

                if (Radius5 > 100)
                    Radius5 = 95;
                else if (Radius5 < 30)
                    Radius5 = 30;

                
                Vreme1 = datumi[0].ToString();
                Vreme2 = datumi[1].ToString();
                Vreme3 = datumi[2].ToString();
                Vreme4 = datumi[3].ToString();
                Vreme5 = datumi[4].ToString();
            }
            catch (Exception e)
            {
                Provera = "Sacekajte da pristignu 5 vrednosti.";
            }
        }
    }
}
