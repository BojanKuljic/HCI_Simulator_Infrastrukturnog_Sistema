﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkService.Model
{
    public class Reaktor : ValidationBase
    {
        private int id;
        private string name;        
        private Tip tipR = new Tip();
        private double value; 
        private string img_src;
        public int Id
        {
            get { return id; }
            set
            {
                if(id != value)
                {
                    id = value;
                    OnPropertyChanged("Id");
                }
            }
        }
        
        public string Id_TextBox { get { return id_textbox; } set { if (id_textbox != value) { id_textbox = value; OnPropertyChanged("Id_TextBox"); } } }
        private string id_textbox;
        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged("Name");
                }
            }
        }

        public Tip TipR
        {
            get { return tipR; }
            set
            {
                if(tipR != value)
                {
                    tipR = value;
                    OnPropertyChanged("TipR");
                }
            }
        }

        public string Img_src
        {
            get { return img_src; }
            set
            {
                if (img_src != value)
                {
                    img_src = value;
                    OnPropertyChanged("Img_src");
                }
            }
        }

        public double Value
        {
            get { return this.value; }
            set
            {
                if (this.value != value)
                {
                    this.value = value;
                    OnPropertyChanged("Value");
                }
            }
        }


        protected override void ValidateSelf()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(this.Id_TextBox))
                    throw new Exception();

                this.Id = Int32.Parse(this.Id_TextBox);

                foreach (Reaktor reaktor in ViewModel.ServerViewModel.Reaktori)
                {
                    if (reaktor.Id == Int32.Parse(this.Id_TextBox))
                    {
                        throw new Exception();
                    }
                }
            }
            catch(Exception e)
            {
                this.ValidationErrors["Id"] = "Id mora biti jedinstven,ceo broj i polje ne sme biti prazno.";
            }

            if (string.IsNullOrWhiteSpace(this.name))
                this.ValidationErrors["Name"] = "Polje ne sme biti prazno.";

            

            if(string.IsNullOrEmpty(this.Img_src))
                this.ValidationErrors["Img_src"] = "Morate odabrati sliku.";

        }
    }
}
