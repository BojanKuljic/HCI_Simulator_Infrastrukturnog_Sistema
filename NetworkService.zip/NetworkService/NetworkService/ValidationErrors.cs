﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkService
{
    public class ValidationErrors : BindableBase
    {
        //recnik trenutnih gresaka za svako polje 
        private readonly Dictionary<string, string> validationErrors = new Dictionary<string, string>();

        public bool IsValid
        {
            get
            {
                return this.validationErrors.Count < 1;
            }
        }

        public string this[string fieldName]
        {
            get                             //za naziv propertyja vrati poruku o gresci ako on postoji u Recniku
            {
                return this.validationErrors.ContainsKey(fieldName) ? this.validationErrors[fieldName] : string.Empty;
            }
            set
            {
                if (this.validationErrors.ContainsKey(fieldName))
                {
                    if (string.IsNullOrWhiteSpace(value))
                        this.validationErrors.Remove(fieldName);    //ako je prazan string izbrisi ga
                    else
                        this.validationErrors[fieldName] = value;   //nova poruka na taj kljuc
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(value))
                        this.validationErrors.Add(fieldName, value);    //ako ne postoji u recniku trenutnih gresaka dodaj je
                }

                this.OnPropertyChanged("IsValid");      //obavestavamo IsValid da se mozda promenio
            }
        }

        public void Clear()
        {
            validationErrors.Clear();
        }
    }
}
